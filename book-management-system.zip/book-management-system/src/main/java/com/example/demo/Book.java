package com.example.demo;

public class Book {
	
	    private String id;
	    private String title;
	    private boolean issued;

	    public Book(String id, String title) {
	        this.id = id;
	        this.title = title;
	        this.issued = false;
	    }

	    public String getId() { return id; }
	    public String getTitle() { return title; }
	    public boolean isIssued() { return issued; }

	    public void setIssued(boolean issued) { this.issued = issued; }
	    
	public Book() {
		// TODO Auto-generated constructor stub
	}

}
