package com.example.demo;


public class User {
    private String name;
    private String bookId;

    public User(String name) {
        this.name = name;
        this.bookId = null;
    }

    public String getName() { return name; }
    public String getBookId() { return bookId; }

    public void setBookId(String bookId) { this.bookId = bookId; }
}
