package com.example.demo;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@Controller
public class Librarycontroller {

    private List<Book> books = new ArrayList<>();
    private Map<String, User> users = new HashMap<>();

    public Librarycontroller() {
        books.add(new Book("B1", "The Alchemist"));
        books.add(new Book("B2", "1984"));
        books.add(new Book("B3", "Clean Code"));
    }

    @GetMapping("/")
    public String home(Model model) {
        model.addAttribute("books", books);
        return "index";
    }

    @PostMapping("/issue")
    public String issue(@RequestParam String username, @RequestParam String bookId) {
        User user = users.computeIfAbsent(username, User::new);
        for (Book book : books) {
            if (book.getId().equals(bookId) && !book.isIssued()) {
                book.setIssued(true);
                user.setBookId(bookId);
                break;
            }
        }
        return "redirect:/";
    }

    @PostMapping("/return")
    public String returnBook(@RequestParam String username) {
        User user = users.get(username);
        if (user != null && user.getBookId() != null) {
            for (Book book : books) {
                if (book.getId().equals(user.getBookId())) {
                    book.setIssued(false);
                    user.setBookId(null);
                    break;
                }
            }
        }
        return "redirect:/";
    }
}
